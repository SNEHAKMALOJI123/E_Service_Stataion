package com.example.hp.e_service_station;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by hp on 9/14/2022.
 */
public class Helpus_page extends AppCompatActivity {
    ImageView call_admin,call_tech;

    String str_call,str_tech;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.helpus_page);
        call_admin=(ImageView)findViewById(R.id.img_call);
        call_tech=(ImageView)findViewById(R.id.img_tech);
        call_admin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_CALL);
                intent.setData(Uri.parse("tel:6363096585" ));
                startActivity(intent);
            }
        });

        call_tech.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_CALL);
                intent.setData(Uri.parse("tel:6360775210" ));
                startActivity(intent);
            }
        });
    }
}
