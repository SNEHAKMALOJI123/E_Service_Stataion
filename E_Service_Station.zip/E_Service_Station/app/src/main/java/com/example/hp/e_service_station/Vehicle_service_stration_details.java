package com.example.hp.e_service_station;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Vehicle_service_stration_details extends AppCompatActivity {

    SharedPrefHandler sharedPrefHandler;
    String string;

    String[] products;
    List<ServiceArray> productList;
    ArrayAdapter<String> adapter;
    Button btn1;


    TextView textView1,textView2,textView3,textView4,textView5,textView6,textView7;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicle_service_stration_details);

        sharedPrefHandler=new SharedPrefHandler(this);

        string=sharedPrefHandler.getSharedPreferences("station");

        getProductByCode(string);

        textView1=(TextView)findViewById(R.id.tv1);
        textView2=(TextView)findViewById(R.id.tv2);
        textView3=(TextView)findViewById(R.id.tv3);
        textView4=(TextView)findViewById(R.id.tv4);
        textView5=(TextView)findViewById(R.id.tv5);
        textView6=(TextView)findViewById(R.id.tv6);
        textView7=(TextView)findViewById(R.id.tv7);
        btn1=(Button)findViewById(R.id.btn_vss);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),Direction_vss_page.class);
                startActivity(i);
            }
        });




    }

    private void getProductByCode(final String string)
    {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Api.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create()) //Here we are using the GsonConverterFactory to directly convert json data to object
                .build();

        Api api = retrofit.create(Api.class);

        Call<List<ServiceArray>> call = api.getServiceDetails(string);

        call.enqueue(new Callback<List<ServiceArray>>() {
            @Override
            public void onResponse(Call<List<ServiceArray>> call, Response<List<ServiceArray>> response) {
                productList = response.body();

                Boolean isSuccess = false;
                if (response.body() != null) {
                    isSuccess = true;
                }

                if (isSuccess) {
                    textView1.setText("Station Id : "+productList.get(0).getstationid());
                    textView2.setText("Station Name : "+ productList.get(0).getstationame());
                    textView3.setText("City : "+ productList.get(0).getcity());
                    textView4.setText("Address : "+productList.get(0).getaddress());
                    textView5.setText("Mobile Number : "+productList.get(0).getmno());
                    textView6.setText("Posrt Details : "+productList.get(0).getportdeatils());
                    textView7.setText("service charge"+productList.get(0).getservicecharge());


                    //finish();

                } else {

                }
            }

            @Override
            public void onFailure(Call<List<ServiceArray>> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

}
