package com.example.hp.e_service_station;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by hp on 9/14/2022.
 */
public class Profile_page extends AppCompatActivity {
    SharedPrefHandler shr;
    EditText first,last,mno,email,city,posatal,password;
    Button update;
    String str_frist,str_last,str_number,str_email,str_city,str_add,str_pass;
    String str_shr_umno;
    String[] product;
    List<User_Account_Array> productList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile_page);
        first=(EditText)findViewById(R.id.et_first);
        last=(EditText)findViewById(R.id.et1_last);
        mno=(EditText)findViewById(R.id.et2_mobile);
        email=(EditText)findViewById(R.id.et3_email);
        city=(EditText)findViewById(R.id.et4_city);
        posatal=(EditText)findViewById(R.id.et5_address);
        password=(EditText)findViewById(R.id.et6_pass);
        update=(Button)findViewById(R.id.btn_update);

        shr=new SharedPrefHandler(this);

        str_shr_umno=shr.getSharedPreferences("umno");

        Toast.makeText(Profile_page.this, "" + str_shr_umno, Toast.LENGTH_SHORT).show();
        getProductByCode(str_shr_umno);
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                str_frist=first.getText().toString();
                str_last=last.getText().toString();
                str_number=mno.getText().toString();
                str_email=email.getText().toString();
                str_city=city.getText().toString();
                str_add=posatal.getText().toString();
                str_pass=password.getText().toString();

                if (str_frist.isEmpty()||str_last.isEmpty()||str_number.length()<10||str_email.isEmpty()||str_city.isEmpty()||str_add.isEmpty()||str_pass.isEmpty()
                        || !str_frist.matches("[a-zA-Z]+")
                        || !str_last.matches("[a-zA-Z]+")
                        || !str_number.matches("^[6-9]\\d{9}")
                        || !str_email.matches("[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+")
                        || !str_city.matches("[a-zA-Z]+"))
                {
                    Toast.makeText(Profile_page.this, "Enter deatils", Toast.LENGTH_SHORT).show();
                }
                else{

                    CreateUserAccount();
                    Toast.makeText(Profile_page.this, "Updated sucessfully"+str_frist+str_last+str_number+str_email+str_city+str_add+str_pass, Toast.LENGTH_SHORT).show();
                }

            }
        });

    }
    private void getProductByCode(final String str_shr_umno)
    {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Api.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create()) //Here we are using the GsonConverterFactory to directly convert json data to object
                .build();

        Api api = retrofit.create(Api.class);

        Call<List<User_Account_Array>> call = api.getUserDetails(str_shr_umno);

        call.enqueue(new Callback<List<User_Account_Array>>() {
            @Override
            public void onResponse(Call<List<User_Account_Array>> call, Response<List<User_Account_Array>> response) {
                productList = response.body();

                Boolean isSuccess = false;
                if (response.body() != null) {
                    isSuccess = true;
                }

                if (isSuccess) {
                    first.setText(productList.get(0).getFristname());
                    last.setText( productList.get(0).getLastname());
                    mno.setText( productList.get(0).getMno());
                    email.setText(productList.get(0).getEmail());
                    city.setText(productList.get(0).getCity());
                    posatal.setText( productList.get(0).getAddress());
                    password.setText( productList.get(0).getPassword());


                    //finish();

                } else {

                }
            }

            @Override
            public void onFailure(Call<List<User_Account_Array>> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
    private void CreateUserAccount() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Api.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        Api api = retrofit.create(Api.class);

        Call<IsExist> call = api.updatepage(
                str_frist, str_last, str_number, str_email, str_city, str_add, str_pass
        );

        call.enqueue(new Callback<IsExist>() {
            @Override
            public void onResponse(Call<IsExist> call, Response<IsExist> response) {
                IsExist responseResult = response.body();

                Boolean isSuccess = false;
                if (responseResult != null) {
                    isSuccess = responseResult.getSuccess();
                }

                if (isSuccess) {

                } else {
                    // Show Creation Failed Message

                }
            }

            @Override
            public void onFailure(Call<IsExist> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

}
