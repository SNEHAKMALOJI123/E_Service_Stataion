package com.example.hp.e_service_station;

/**
 * Created by hp on 9/14/2022.
 */
public class User_Account_Array {
    private  String fristname;
    private  String lastname;
    private  String mno;
    private  String email;
    private  String city;
    private  String address;
    private  String  posatal;
    private  String password;


    public  User_Account_Array(String mno,String fristname,String lastname,String email,String city,String address,String password)
    {
        this.fristname=fristname;
        this.lastname=lastname;
        this.mno=mno;
        this.email=email;
        this.city=city;
        this.address=address;
        this.password=password;
    }
    public String getFristname(){
        return  fristname;

    }
    public String getLastname(){
        return  lastname;

    }

    public String getMno(){
        return  mno;

    }

    public String getEmail(){
        return  email;

    }

    public String getCity(){
        return  city;

    }

    public String getAddress(){
        return  address;

    }

    public String getPassword(){
        return  password;

    }


}
