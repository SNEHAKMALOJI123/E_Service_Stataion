package com.example.hp.e_service_station;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by hp on 9/12/2022.
 */
public class Login_page extends AppCompatActivity {
    SharedPrefHandler shr;
    EditText e1,e2;
    TextView tv;
    Button btn;
    String mno,pass;
    String str_shr_mno,str_shr_pass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_page);
        shr=new SharedPrefHandler(this);
        e1=(EditText)findViewById(R.id.et_login);
        e2=(EditText)findViewById(R.id.et1_login);
        btn=(Button)findViewById(R.id.btn_login);
        str_shr_mno=shr.getSharedPreferences("mno");
        str_shr_pass=shr.getSharedPreferences("pass");
        tv=(TextView)findViewById(R.id.tv_new);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mno=e1.getText().toString();
                pass=e2.getText().toString();
                if (mno.length()<10 || pass.isEmpty()||!mno.matches("^[6-9]\\d{9}"))

                {
                    Toast.makeText(Login_page.this, "Enter deatils", Toast.LENGTH_SHORT).show();
                }
                else if (mno.equals(str_shr_mno)&& pass.equals(str_shr_pass)){
                    shr.setSharedPreferences("login","true");
                    shr.setSharedPreferences("umno",mno);
                    Intent i = new Intent(getApplication(),Home_page.class);
                    startActivity(i);
                    Toast.makeText(Login_page.this, "Login successfully", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(Login_page.this, "login failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplication(),Signup_page.class);
                startActivity(i);
                Toast.makeText(Login_page.this, "signup page", Toast.LENGTH_SHORT).show();
            }
        });

    }
}
