package com.example.hp.e_service_station;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by hp on 9/14/2022.
 */
public class Aboutapp_page extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.aboutapp_page);
    }
}
