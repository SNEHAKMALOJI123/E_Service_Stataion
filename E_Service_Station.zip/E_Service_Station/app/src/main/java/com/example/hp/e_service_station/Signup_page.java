package com.example.hp.e_service_station;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by hp on 9/12/2022.
 */
public class Signup_page extends AppCompatActivity{
    SharedPrefHandler shr;
    EditText e1,e2,e3,e4,e5,e6,e7;
    Button btn1;
    String first,last,mno,email,city,add,pass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup_page);
        shr=new SharedPrefHandler(this);
        e1=(EditText)findViewById(R.id.et_signup);
        e2=(EditText)findViewById(R.id.et1_signup);
        e3=(EditText)findViewById(R.id.et2_signup);
        e4=(EditText)findViewById(R.id.et3_signup);
        e5=(EditText)findViewById(R.id.et4_signup);
        e6=(EditText)findViewById(R.id.et5_signup);
        e7=(EditText)findViewById(R.id.et6_signup);
        btn1=(Button)findViewById(R.id.btn_signup);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                first=e1.getText().toString();
                last=e2.getText().toString();
                mno=e3.getText().toString();
                email=e4.getText().toString();
                city=e5.getText().toString();
                add=e6.getText().toString();
                pass=e7.getText().toString();

                if (first.isEmpty()||last.isEmpty()||mno.length()<10||email.isEmpty()||city.isEmpty()||add.isEmpty()||pass.isEmpty()
                        ||!first.matches("[a-zA-Z]+")
                        ||!last.matches("[a-zA-Z]+")
                        ||!mno.matches("^[6-9]\\d{9}")
                        ||!email.matches("[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+")
                        ||!city.matches("[a-zA-Z]+"))
                {
                    Toast.makeText(Signup_page.this, "Enter details", Toast.LENGTH_SHORT).show();
                }
                else{
                    shr.setSharedPreferences("mno",mno);
                    shr.setSharedPreferences("pass", pass);
                    CreateUserAccount();
                    Intent i = new Intent(getApplication(),Login_page.class);
                    startActivity(i);

                    Toast.makeText(Signup_page.this, "signup sucessfully", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }
    private void CreateUserAccount() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Api.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        Api api = retrofit.create(Api.class);

        Call<IsExist> call = api.Signup_page(
                first,last,mno,email,city,add,pass
        );

        call.enqueue(new Callback<IsExist>() {
            @Override
            public void onResponse(Call<IsExist> call, Response<IsExist> response) {
                IsExist responseResult = response.body();

                Boolean isSuccess = false;
                if (responseResult != null) {
                    isSuccess = responseResult.getSuccess();
                }

                if (isSuccess) {

                } else {
                    // Show Creation Failed Message

                }
            }

            @Override
            public void onFailure(Call<IsExist> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

}
