package com.example.hp.e_service_station;

/**
 * Created by hp on 9/12/2022.
 */
import java.util.List;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface Api
{
    String BASE_URL = "https://cagiest-cheeks.000webhostapp.com/API2/";


    @POST("Insert_signup.php")
    Call<IsExist> Signup_page(
            @Query("f1") String first,
            @Query("f2") String last,
            @Query("f3") String mno,
            @Query("f4") String email,
            @Query("f5") String city,
            @Query("f6") String add,
            @Query("f7") String pass


    );

    @GET("https://cagiest-cheeks.000webhostapp.com/API2/get_user_profile.php")
    Call<List<User_Account_Array>> getUserDetails(@Query("f1") String str_shr_umno);

    @GET("https://cagiest-cheeks.000webhostapp.com/API2/get_station_name.php")
    Call<List<ServiceArray>> getServiceName(@Query("f1") String str_city);



    @POST("update_user_account.php")
    Call<IsExist> updatepage(
            @Query("f1") String str_frist,
            @Query("f2") String str_last,
            @Query("f3") String str_number,
            @Query("f4") String str_email,
            @Query("f5") String str_city,
            @Query("f6") String str_add,
            @Query("f7") String str_pass


    );




    @GET("https://cagiest-cheeks.000webhostapp.com/API2/get_station_details.php")
    Call<List<ServiceArray>> getServiceDetails(@Query("f1") String string);

    @GET("https://cagiest-cheeks.000webhostapp.com/API2/get_Cstation_name.php")
    Call<List<ChargeArray>> getChargeName(@Query("f1") String str_cities);

    @GET("https://cagiest-cheeks.000webhostapp.com/API2/get_Cstation_details.php")
    Call<List<ChargeArray>> getChargeDetails(@Query("f1") String string_charge);








}
