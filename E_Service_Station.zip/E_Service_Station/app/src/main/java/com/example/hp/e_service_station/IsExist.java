package com.example.hp.e_service_station;

/**
 * Created by hp on 9/12/2022.
 */
class IsExist {
    private Boolean success;

    public IsExist(Boolean success) {
        this.success = success;
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }
}
