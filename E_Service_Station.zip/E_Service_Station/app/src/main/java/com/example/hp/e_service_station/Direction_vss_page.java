package com.example.hp.e_service_station;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebView;

/**
 * Created by hp on 9/16/2022.
 */
public class Direction_vss_page extends AppCompatActivity {
    WebView service;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.direction_vss_page);
        service=(WebView)findViewById(R.id.wv_vss);
        service.loadUrl("https://maps.google.com/");
    }
}
