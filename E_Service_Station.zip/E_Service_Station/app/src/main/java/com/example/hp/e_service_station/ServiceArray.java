package com.example.hp.e_service_station;

/**
 * Created by hp on 9/14/2022.
 */
public class ServiceArray {
    private  String stationid;
    private  String stationame;
    private  String city;
    private  String address;
    private  String mno;
    private  String portdeatils;
    private  String servicecharge;
    private  String latitude;
    private  String longitude;




    public ServiceArray(String stationid, String stationame,String city,String address, String mno, String portdeatils,String servicecharge,String latitude,String longitude)
    {
        this.stationid=stationid;
        this.stationame=stationame;

        this.city=city;

        this.address=address;
        this.mno=mno;
        this.portdeatils=portdeatils;
        this.servicecharge=servicecharge;
        this.latitude=latitude;
        this.longitude=longitude;

      }
    public String getstationid(){
        return  stationid;

    }
    public String getaddress(){
        return  address;

    }

    public String getstationame(){
        return  stationame;

    }


    public String getcity(){
        return  city;

    }

    public String getmno(){
        return  mno;

    }


    public String getportdeatils(){
        return  portdeatils;

    }

    public String getservicecharge(){
        return  servicecharge;

    }

    public String getlatitude(){
        return  latitude;

    }

    public String getlongitude(){
        return  longitude;

    }


}
